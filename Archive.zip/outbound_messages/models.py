from django.db import models

"""
class MessageType(models.Model):
    message_type = models.CharField(max_length=20)

    class Meta:
        verbose_name = "Message Type"
        verbose_name_plural = "Message Types"

    def __str__(self):
        return self.message_type


class MessageSource(models.Model):
    pass


class Message(models.Model):

    DELIVERED = 'D'
    SUBMITTED = 'S'
    PENDING = 'P'
    FAILED = 'F'
    BLACKLIST = 'B'

    NOTIFY_STATUS = (
        (SUBMITTED, 'SUBMITTED'),
        (DELIVERED, 'DELIVERED'),
        (PENDING, 'PENDING'),
        (FAILED, 'FAILED'),
        (BLACKLIST, 'BLK_REJECTED'),
    )
    message_type = models.CharField(max_length=30, db_index=True)
    connector_code = models.CharField(max_length=50, db_index=True)
    provider_code = models.CharField(max_length=50, db_index=True)
    traffic_id = models.CharField(max_length=50)
    in_msgid = models.CharField(max_length=50, null=True, blank=True)
    ext_msgid = models.CharField(max_length=50, null=True, blank=True)
    msg_src = models.CharField(max_length=50, db_index=True)
    sender = models.CharField(max_length=20)
    recipient = models.CharField(max_length=20, db_index=True)
    subject = models.CharField(max_length=100)
    body = models.TextField()
    retry_count = models.CharField(max_length=20)
    status = models.CharField(max_length=20, db_index=True, choices=NOTIFY_STATUS)

    class Meta:
        verbose_name = "Message"
        verbose_name_plural = "Messages"

    def __str__(self):
        return self.message_type

"""