from django.apps import AppConfig


class OutboundMessagesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'outbound_messages'
