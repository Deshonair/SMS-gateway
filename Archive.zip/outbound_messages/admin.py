from django.contrib import admin
"""
# Register your models here.

from outbound_messages.models import MessageType

admin.site.register(MessageType)
"""
