from django.db import models


class Provider(models.Model):
    name = models.CharField(max_length=40)

    class Meta:
        verbose_name = "Provider"
        verbose_name_plural = "Providers"

    def __str__(self):
        return self.name


class Protocol(models.Model):
    name = models.CharField(max_length=30)

    class Meta:
        verbose_name = "Protocol"
        verbose_name_plural = "Protocols"

    def __str__(self):
        return self.name


class Channel(models.Model):
    name = models.CharField(max_length=50)

    class Meta:
        verbose_name = "Channel"
        verbose_name_plural = "Channels"

    def __str__(self):
        return self.name

"""
class ConnectorType(models.Model):
    connector_type = models.CharField(max_length=20)

    class Meta:
        verbose_name = "Connector Type"
        verbose_name_plural = "Connector Types"

    def __str__(self):
        return self.connector_type
"""


class Connector(models.Model):
    provider = models.ForeignKey(Provider, on_delete=models.CASCADE)
    channel = models.ForeignKey(Channel, on_delete=models.CASCADE)
    protocol = models.ForeignKey(Protocol, on_delete=models.CASCADE)
    name = models.CharField(max_length=50)
    connector_id = models.CharField(max_length=20)

    class Meta:
        verbose_name = "Connector"
        verbose_name_plural = "Connectors"

    def __str__(self):
        return self.name



