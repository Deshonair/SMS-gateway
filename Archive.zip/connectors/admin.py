from django.contrib import admin

# Register your models here.

from connectors.models import Provider
from connectors.models import Protocol
from connectors.models import Channel
from connectors.models import Connector

admin.site.site_header = "Message Gateway"
admin.site.site_title = "Message Gateway"
admin.site.index_title = "Message Gateway"


class ConnectorAdmin(admin.ModelAdmin):
    list_display = ['id', 'provider', 'protocol', 'channel',  'connector_id']
    list_filter = ['protocol', 'provider']


admin.site.register(Provider)
admin.site.register(Protocol)
admin.site.register(Channel)
admin.site.register(Connector, ConnectorAdmin)

