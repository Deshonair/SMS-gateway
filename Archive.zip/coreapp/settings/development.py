from .base import *

import os

DEBUG = True
ALLOWED_HOSTS = ['127.0.0.1']

INSTALLED_APPS = INSTALLED_APPS + [
    'clients',
    'connectors',
    'notifications',

]

SESSION_COOKIE_NAME = 'ucpsessionid2'
STATIC_URL = '/static/'
STATIC_ROOT = os.path.join(PROJECT_PATH, 'static/')