from django.contrib import admin

# Register your models here.

from notifications.models import Message
from notifications.models import MessageDispatch

admin.site.register(Message)
admin.site.register(MessageDispatch)
