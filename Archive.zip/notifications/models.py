from django.db import models


class Message(models.Model):
    internal_msg_id = models.CharField(max_length=50)
    external_msg_id = models.CharField(max_length=50, null=True, blank=True)
    msg_src = models.CharField(max_length=50, db_index=True)
    subject = models.CharField(max_length=100)
    body = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Message"
        verbose_name_plural = "Messages"

    def __str__(self):
        return self.message_type


class MessageDispatch(models.Model):
    DELIVERED = 'D'
    SUBMITTED = 'S'
    PENDING = 'P'
    FAILED = 'F'
    BLACKLIST = 'B'

    NOTIFY_STATUS = (
        (SUBMITTED, 'SUBMITTED'),
        (DELIVERED, 'DELIVERED'),
        (PENDING, 'PENDING'),
        (FAILED, 'FAILED'),
        (BLACKLIST, 'BLK_REJECTED'),
    )
    message = models.ForeignKey(Message, on_delete=models.CASCADE)
    traffic_id = models.CharField(max_length=50)
    provider_ref = models.CharField(max_length=100, null=True, blank=True)
    internal_msg_id = models.CharField(max_length=100, db_index=True)
    external_msg_id = models.CharField(max_length=100, db_index=True)
    channel = models.CharField(max_length=50)
    connector = models.CharField(max_length=50, db_index=True, )
    provider = models.CharField(max_length=50, db_index=True)
    sender = models.CharField(max_length=20)
    recipient = models.CharField(max_length=20, db_index=True)
    retry_count = models.PositiveIntegerField(default=0)
    status = models.CharField(max_length=20, db_index=True, choices=NOTIFY_STATUS)

    class Meta:
        verbose_name = "Message Dispatch"
        verbose_name_plural = "Message Dispatches"

    def __str__(self):
        return "%s %s %s" % (self.message, self.recipient, self.status)


